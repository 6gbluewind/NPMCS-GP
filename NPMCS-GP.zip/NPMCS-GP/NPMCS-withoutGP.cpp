//NETLAP-LENGTH_parent child  �Կ��Է��ʵĺ��ӽ��������Ƿ�Ϊ��ʹ�ý��
#include <iostream.h>
#include <string.h>
#include <afxwin.h>
#include <vector>
#include <fstream>
#include <cmath>
using namespace std;
struct node
{
	int name;
	int min_root,max_root;
	int minLeaf,maxLeaf;
	vector <int> parent;
	vector <int> children;
	//int *parent,pn;
	//int *children,pc;
	bool used;
	bool toroot;//�ִ�����
	//bool toleave;//�ִ���Ҷ
};
#define N 800000
#define M 1000
char S1[N];
char S2[N];
char p[M]="0";
struct sub_ptn_struct
{
	char start,end;		//
	int min,max;		//
};
struct occurrence
{
	vector <int > position;
	vector <int > record;
};
vector <occurrence> store;
vector <occurrence> compare;
vector <occurrence> final;
vector <int> FenShu;
sub_ptn_struct sub_ptn[M];  //pattern p[i]
int ptn_len=0;  //the length of pattern
int seq_len=0;
int maxgap=-1;
int jump = 0;
int level = 0;
occurrence occ;
occurrence occin;//�������е�λ�ã�

void createnettree_length(vector <node> *nettree, char S[N])
{
	int n=strlen(S);
	for (int i=0;i<ptn_len+1;i++)
		nettree[i].resize (n);//�������ʼ��
	int *start;
	start=new int[ptn_len+1];
	for (i=0;i<ptn_len+1;i++)
		start[i]=0;
	for (i=0;i<n;i++)
	{
		//��ÿ���ַ���һ���
		//�Խ����г�ʼ����
		//if (i==382)
		//	int tmp=5;
		node anode;
		node fnode;
		fnode.name=-1;
		anode.name =i+1;
		anode.parent.resize (0);
		anode.children.resize (0);
		anode.used =false;//û��ʹ��Ϊ�٣�ʹ��Ϊ��
		fnode.used =true;
		for(int j=0;j<=ptn_len;j++){
			if(j==0){
				if(sub_ptn[j].start ==S[i]){
					anode.toroot =true;
					nettree[j][i]=anode;
				}
				else
					nettree[j][i]=fnode;
			}
			else{
				if(sub_ptn[j-1].end==S[i])
					nettree[j][i]=anode;
				else
					nettree[j][i]=fnode;
			}
		}
		for (j=0;j<ptn_len;j++)
		{
			if (sub_ptn[j].end==S[i])
			{
				//�������  ������
				for (int k=start[j];k<i;k++)
				{
					int name=nettree[j][k].name;
					if(name==-1){
						start[j]++;
						continue;
					}
					else if(nettree[j+1][i].name-nettree[j][k].name-1>sub_ptn[j].max )
					{
						//��������Ͻ죬�α����
						start[j]++;
					}
					else
						break;
				}
				for (k=start[j];k<i;k++)
				{
					if(nettree[j][k].name==-1)
						continue;
					//�ڼ�϶Լ��֮��
					//�������ӹ�ϵ
					int nc=nettree[j][k].children.size ();
					nettree[j][k].children.resize (nc+1);
					nettree[j][k].children[nc]=i;//�洢λ��
					int np=nettree[j+1][i].parent.size ();
					nettree[j+1][i].parent.resize(np+1);
					nettree[j+1][i].parent[np]=k;
				}

			}
			else
				continue;
		}
	}
	delete []start;
}
void displaynettree(vector <node> *nettree)
{
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size();j++)
			if (nettree[i][j].used ==false)
				cout <<nettree[i][j].name <<"\t";
			else
				cout<<"\t";
		cout <<endl;
	}
}

#include<stack>
struct storenode
{
	int position;
	int level;
};

void updatenettree_occurrence(vector <node> *nettreeA, vector <node> *nettreeB,occurrence &occl)
{
	//���㷨�����ƣ�����ȫ�����������������з�ʽ����Ӱ��Ľڵ��������
	//���и��׺��ӵĶ�����
	for (int layer=0;layer<ptn_len+1;layer++)
	{
		int position=occl.position[layer];
		int record=occl.record[layer];
		if(record==1){
			nettreeA[layer][position-1].used=true;
			nettreeA[layer][position-1].toroot=false;
		}
		else{
			nettreeB[layer][position-1].used=true;
			nettreeB[layer][position-1].toroot=false;
		}
	}	
}
int minvaleposition(int *nodenumber)
{
	int p=ptn_len;
	for (int i=p-1;i>=0;i--)
	{
		if (nodenumber[i]<=nodenumber[p])
			p=i;
	}
	return p;
}
void displayocc(occurrence &occ)
{
	cout <<"<";
	for (int i=0;i<ptn_len;i++)
		cout <<occ.position[i]<<"_"<<occ.record[i]<<",\t";
	cout <<occ.position [i]<<"_"<<occ.record[i];
	cout <<">"<<"\t"<<endl;
}
void displaychild(vector <node> *nettree)
{
	cout <<"--------child----------------\n";
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size ();j++)
		{
			//if (nettree[i][j].LPN >0)
			{
				//�Բ��ִܵ���Ҷ��Ľ�㲻����ʾ
				cout <<nettree[i][j].children.size ()  <<"\t";
			}
		}
		cout <<endl;
	}
}
void displayparent(vector <node> *nettree)
{
	cout <<"--------child----------------\n";
	for (int i=0;i<ptn_len+1;i++)
	{
		cout <<i<<":";
		for (int j=0;j<nettree[i].size ();j++)
		{
			//if (nettree[i][j].LPN >0)
			{
				//�Բ��ִܵ���Ҷ��Ľ�㲻����ʾ
				cout <<nettree[i][j].parent.size ()  <<"\t";
			}
		}
		cout <<endl;
	}
}


void findsame(vector <node> *nettree,int column,int row){
	for(int i=0;i<row-1;i++){
		if(nettree[i][column].name!=-1){
			nettree[i][column].used=true;
			nettree[i][column].toroot=false;
		}
	}
}

int matching1(vector <node> *nettreeA, vector <node> *nettreeB,int jump,int times){
	int positionA=-1;
	int positionB=-1;
	int record = 0;
	for (;level>=0;level--){
		if(jump<times){
			//���ݺ���������˫��
			int position=occin.position [level+1];//�����������е�λ��
			int t=-1;
			if(occin.record[level+1]==1){
				int	ps=nettreeA[level+1][position].parent.size();//��ǰ����˫����
				int d2=-1;
				for (t=ps-1;t>=0;t--)
				{
					int parent=nettreeA[level+1][position].parent[t];//����˫�׵�λ�ã���λ�ñ�ʾ���������е�ʵ��λ��-1
					int d2=-1;
					if(nettreeA[level][parent].used==true)
						continue;
					int d1=position-parent;
					for(int i=nettreeB[level].size()-1;i>=0;i--){
						if(nettreeB[level][i].used==true)
							continue;
						d2= position - i;
						if(d2 >= 0){
							positionB = i;
							break;
						}
					}
					if(record==1&&d2==0){
						findsame(nettreeA,positionB,level);
						for(int j=positionB-1;i>=0;i--){
							if(nettreeB[level][j].used==true)
								continue;
							d2 = position - j;
							positionB=j;
							break;
						}
					}
					if(d2 >= d1 || d2 < 0){
						occin.position[level]=parent;
						occin.record[level]=1;
						int value=nettreeA[level][parent].name;
						occ.position [level]=value;
						occ.record[level]=1;
						break;
					}
					else{
						if(d2==0){
							record=1;
						}
						occin.position[level]=positionB;	
						occin.record[level]=2;
						int value=nettreeB[level][positionB].name;
						occ.position[level]=value;
						occ.record[level]=2;
						jump+=1;
						break;
					}
				}
				if(t == -1){
					for(int i=nettreeB[level].size()-1;i>=0;i--){
						if(nettreeB[level][i].used==true)
							continue;
						d2= position - i;
						if(d2 >= 0){
							positionB = i;
							occin.position[level]=positionB;	
							occin.record[level]=2;
							int value=nettreeB[level][positionB].name;
							occ.position[level]=value ;
							occ.record[level]=2;
							jump+=1;
							break;
						}
					}
					if(d2 < 0){
						return 0;
					}
				}
			}
			else{
				int ps=nettreeB[level+1][position].parent.size ();//��ǰ����˫����
				int d2=-1;
				for (t=ps-1;t>=0;t--)
				{
					int parent=nettreeB[level+1][position].parent[t];//����˫�׵�λ��
					if(nettreeB[level][parent].used==true)
						continue;
					int d1=position-parent;
					for(int i=nettreeA[level].size()-1;i>=0;i--){
						if(nettreeA[level][i].used==true)
							continue;
						d2= position - i;
						if(d2 >= 0){
							positionA = i;
							break;
						}
					}
					if(record==1&&d2==0){
						findsame(nettreeB,positionA,level);
						for(int j=positionA-1;j>=0;j--){
							if(nettreeA[level][j].used==true)
								continue;
							d2 = position - j;
							positionA=j;
							break;
						}
					}
					if(d2 >= d1|| d2 < 0){
						occin.position[level]=parent;
						occin.record[level]=2;
						int value=nettreeB[level][parent].name;
						occ.position [level]=value;
						occ.record[level]=2;
						break;
					}
					else{
						if(d2==0){
							record=1;
						}
						occin.position[level]=positionA;	
						occin.record[level]=1;
						int value=nettreeA[level][positionA].name;
						occ.position[level]=value ;
						occ.record[level]=1;
						jump+=1;
						break;
					}
				}
				if(t == -1){
					for(int i=nettreeA[level].size()-1;i>=0;i--){
						if(nettreeA[level][i].used==true)
							continue;
						d2= position - i;
						if(d2 >= 0){
							positionA = i;
							occin.position[level]=positionA;	
							occin.record[level]=1;
							int value=nettreeA[level][positionA].name;
							occ.position[level]=value ;
							occ.record[level]=1;
							jump+=1;
							break;
						}
					}
					if(d2 < 0){
						return 0;
					}
				}
			}
		}
		else
			break;
	}
	return jump;
}

int matching2(vector <node> *nettree, int jump){
	int flag=-1;
	int len=level;
	int *pos;
	pos=new int [len+1];
	while(level>=0){
		int position=occin.position[level+1];  //position��ʾ��������s��ʵ��λ��
		int ps=nettree[level+1][position].parent.size();
		if(flag!=0){
			if(ps==0)
				return 0;
			pos[level]=ps;
		}
		for(int j=pos[level]-1;j>=0;j--){
			int parent=nettree[level+1][position].parent[j];
			if(nettree[level][parent].used==true)
				continue;
			occin.position[level]=parent;	
			occin.record[level]=occin.record[level+1];
			int value=nettree[level][parent].name;
			occ.position[level]=value;
			occ.record[level]=occin.record[level+1];
			pos[level]=j;
			break;
		}
		if(j==-1){  //��ʾû�з��������Ľ�㣬��Ҫ�˳�ѭ��
			if(level==len){
				return 0;
			}
			else{
				level++;
				flag=0;
			}
		}
		else{
			level--;
			flag=-1;
		}
	}
	return jump;
}


void countnumber(vector <node> *nettreeA,vector <node> *nettreeB,int end){
	int time = 1;
	for (int pos=nettreeA[end].size()-1;pos>=0;pos--){
		if(nettreeA[end][pos].used==true){
			continue;
		}
		store.resize(0);	
		//��������
		occ.position.resize (ptn_len+1);
		occ.record.resize(ptn_len+1);
		occin.position.resize (ptn_len+1);
		occin.record.resize(ptn_len+1);
		occin.position[end]=pos;   //�洢��pos��������ʵ��λ��-1
		occin.record[end]=1;
		occ.position[end]=nettreeA[end][pos].name;
		occ.record[end]=1;
		nettreeA[end][pos].used =true;
		nettreeA[end][pos].toroot =false;
		for(int j=time;j<=time;j++){
			level = end-1;
			while(level>=0){
				if(jump<j)
					jump = matching1(nettreeA,nettreeB,jump,j);
				else{
					if(occ.record[level+1]==1)
						jump = matching2(nettreeA,jump);
					else
						jump = matching2(nettreeB,jump);
				}
				if(jump==0&&level!=-1)
					break;
			}
			if(level==-1){
				int len = store.size();
				store.resize(len+1);
				store[len]=occ;
				level = end-1;
				jump = 0;
				//displayocc(store[len]);
			}
			else{
				break;
			}
		}
		int length = store.size();
		if(length > 0){
			int index = 0;
			int lenf=0;
			int lenscore=0;
			if(length == 1){
				lenf=final.size();
				final.resize(lenf+1);
				final[lenf]=store[0];
				final.resize(lenf+1);
				final[lenf]=store[index];
			}
			//displayocc(final[lenf]);
			updatenettree_occurrence(nettreeA,nettreeB,final[lenf]);
			//displaynettree(nettreeB);
		}
		else
			continue;
	}
}
//version 1  ������Ҷ�Ӳ������
void nonoverlength()
{
	vector <node> *nettreeA;
	vector <node> *nettreeB;
	nettreeA=new vector <node> [ptn_len+1];
	int *nodenumberA;
	nodenumberA=new int [ptn_len+1];
	createnettree_length(nettreeA,S1);
	//displaynettree(nettreeA);
	for(int i=0;i<=ptn_len;i++){
		nodenumberA[i]=nettreeA[i].size();
	}
	//updatenettree(nettreeA,nodenumberA);
	nettreeB=new vector <node> [ptn_len+1];
	int *nodenumberB;
	nodenumberB=new int [ptn_len+1];
	createnettree_length(nettreeB,S2);
	//displaynettree(nettreeB);
	for(i=0;i<=ptn_len;i++){
		nodenumberB[i]=nettreeB[i].size();
	}

	final.resize (0);
	countnumber(nettreeA,nettreeB,ptn_len);
}

void dealrange(char *p,int len)      
//put sub-pattern "a[1,3]b" into sub_ptn and sub_ptn.start=a��sub_ptn.end=b, sub_ptn.min=1��sub_ptn.max=3
{
	sub_ptn[ptn_len].start =p[0];
	sub_ptn[ptn_len].end =p[len];
	if (len==1)
	{
		sub_ptn[ptn_len].max =sub_ptn[ptn_len].min=0;
	}
	else
	{
		int value=0;
		int i;
		for ( i=2;p[i]!=',';i++)
			value=value*10+p[i]-48;
		sub_ptn[ptn_len].min=value;		
		value=0;
		for (int j=i+1;p[j]!=']';j++)
			value=value*10+p[j]-48;
		sub_ptn[ptn_len].max=value;
	}
	if (sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1>maxgap)
		maxgap=sub_ptn[ptn_len].max-sub_ptn[ptn_len].min+1;
	ptn_len++;  //ptn_len�ĳ��ȱ�������patternС1
}

void convert_p_to_ruler(char *p)     //transform p into sub_ptn
{
	char st,en;
	int l,r ;
	int len=strlen(p);
	st=p[0];
	en=p[len-1];
	if (isalpha(st) && isalpha(en))
	{
		l=0;
		for (int i=1;i<len;i++)
		{
			if (isalpha(p[i]))
			{
				r=i;
				dealrange(p+l,r-l);  //p+l��Ϊ�˽�ָ��������һ����ĸ���Ŀ�ͷ char p[M]="a[0,1]g[0,1]a[0,2]a";
				l=i;
			}
		}
	}
	else
	{
		cout<<"irregular pattern.\n";
		exit(-1);
	}
}
void disp_pattern()         //display the array sub_ptn
{
	for (int i=0;i<ptn_len;i++)
	{
		//printf("%c\t%d\t%d\t%c\n",sub_ptn[i].start ,sub_ptn[i].min , sub_ptn[i].max ,sub_ptn[i].end );
		cout<<sub_ptn[i].start<<"\t"<<sub_ptn[i].min<<"\t"
			<<sub_ptn[i].max<<"\t"<<sub_ptn[i].end<<endl;
	}
	//cout<<ptn_len<<endl;
}
void Inputstr1(char *fn,char *str)
{
	FILE* fp=fopen(fn,"r+");
	if (NULL==fp)
	{
		cout<<"Cannot find the file.\n";
		return;
	}
	fseek(fp,0,SEEK_END); 
	int len =ftell(fp);  //ftell���ص��ǵ�ǰ�ڵ�λ��
	fseek(fp,0,0); 
	fscanf(fp, "%s",str);
}
void Inputstr2(char *fn,char *str)
{
	FILE* fp=fopen(fn,"r+");
	if (NULL==fp)
	{
		cout<<"Cannot find the file.\n";
		return;
	}
	fseek(fp,0,SEEK_END); 
	int len =ftell(fp);  //ftell���ص��ǵ�ǰ�ڵ�λ��
	fseek(fp,0,0); 
	fscanf(fp, "%s",str);
}
char* put_p(char* px, int xx)
{
	int put_i = 0;
	int p_len = strlen(px);
	
	for(put_i = 0; put_i < p_len; put_i++)
	{
		p[put_i] = px[put_i];
	}
	
	return px;
}

void CreatTxt(char* pathName,int length)//����txt�ļ�
{
 ofstream fout(pathName);
 if (fout) { // ��������ɹ�
  for (int i = 0; i < length; i++)
  {
	  occurrence occf=final[i];
	  for(int j=0;j<ptn_len+1;j++){
		  fout <<occf.position[j]<<"_"<<occf.record[j]<<"\t"; // ʹ����coutͬ���ķ�ʽ����д��
	  }
	  fout<<endl;

  }
  
  fout.close();  // ִ���������ر��ļ����
 }
}

void main()
{
	char p1[200]="a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a[0,3]t[0,3]a";    //P1
	char p2[200]="g[1,5]t[0,6]a[2,7]g[3,9]t[2,5]a[4,9]g[1,8]t[2,9]a"; //P2
	char p3[200]="g[1,9]t[1,9]a[1,9]g[1,9]t[1,9]a[1,9]g[1,9]t[1,9]a[1,9]g[1,9]t";  //P3
	char p4[200]="g[1,5]t[0,6]a[2,7]g[3,9]t[2,5]a[4,9]g[1,8]t[2,9]a[1,9]g[1,9]t";  //P4
	char p5[200]="a[0,10]a[0,10]t[0,10]c[0,10]g[0,10]g";  //P5
	char p6[200]="a[0,5]t[0,7]c[0,9]g[0,11]g";  //P6
	char p7[200]="a[0,5]t[0,7]c[0,6]g[0,8]t[0,7]c[0,9]g";  //P7
	char p8[200]="a[5,6]c[4,7]g[3,8]t[2,8]a[1,7]c[0,9]g";  //P8
	char p9[200]="c[0,5]t[0,5]g[0,5]a[0,5]a";  //P9
	char p[M]="A[0,2]T[0,2]A";
	strcpy(S1,"ATATAA");
	strcpy(S2,"TATATA");
	
	//cout<<"Please input minlen and maxlen:";
	//cout << "ѡ�ڼ���ģʽ��" << endl;
	int xx = 0;
	//cin >> xx;
    switch(xx) {
    case 1:
		put_p(p1, 1);
		break;
    case 2:
		put_p(p2, 2);
		break;
	case 3:
		put_p(p3, 3);
		break;
    case 4:
		put_p(p4, 4);
		break;
	case 5:
		put_p(p5, 5);
		break;
	case 6:
		put_p(p6, 6);
		break;
    case 7:
		put_p(p7, 7);
		break;
	case 8:
		put_p(p8, 8);
		break;
    case 9:
		put_p(p9, 9);
		break;
    }
	convert_p_to_ruler(p);
	cout<<"The pattern can written as follows:\n";
	disp_pattern();		
	cout<<p<<endl;
	//char fsn1[]="dataset\\S1.txt";
	//char fsn2[]="dataset\\S2.txt";
	//Inputstr(fpn,p);
	//Inputstr1(fsn1,S1);
	//Inputstr2(fsn2,S2);
	//cout<<S<<endl;

	LARGE_INTEGER cpuFreq;
	LARGE_INTEGER startTime;
	LARGE_INTEGER endTime;
	
	QueryPerformanceFrequency(&cpuFreq);
	QueryPerformanceCounter(&startTime);
	//DWORD begintime=GetTickCount();
	for(int m=0;m<100;m++){
		nonoverlength();
	}
	//DWORD endtime=GetTickCount();
	QueryPerformanceCounter(&endTime);
	double last = (((endTime.QuadPart - startTime.QuadPart) * 1000000) / cpuFreq.QuadPart);
	cout << last << " us" << endl;
	int numcount = 0;
	for (int i=0;i<final.size();i++)
	{
		displayocc(final[i]);
		numcount++;
	}
	CreatTxt("F:\\c++work\\1.txt",final.size());
	cout << numcount << endl;
	//cout <<"��ʱ"<<endtime-begintime<<"ms. \n";
	cout <<"����"<<final.size ()<<"������\n";

}